export default function Container({ children }) {
    return <div className="wrapper">{children}</div>;
}
